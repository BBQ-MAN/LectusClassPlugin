<?php
/**
 * Custom functions for Lectus Academy theme
 *
 * @package LectusAcademy
 */

// Custom functions will be added here as needed