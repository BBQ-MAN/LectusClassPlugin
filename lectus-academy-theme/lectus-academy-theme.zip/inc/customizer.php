<?php
/**
 * Theme Customizer
 *
 * @package LectusAcademy
 */

function lectus_academy_customize_register($wp_customize) {
    // Add sections, settings, and controls here
}