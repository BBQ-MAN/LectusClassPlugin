<?php
/**
 * Custom widgets
 *
 * @package LectusAcademy
 */

// Custom widgets will be added here as needed