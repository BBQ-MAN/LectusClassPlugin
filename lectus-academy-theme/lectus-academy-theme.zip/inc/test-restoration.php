<?php
/**
 * Test Site Configuration Restoration
 * 
 * This file provides functionality to restore the complete test site configuration
 * including pages, menus, theme options, and integration with Lectus Class System.
 * 
 * @package LectusAcademy
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Lectus_Academy_Test_Restoration {
    
    /**
     * Cache duration for status checks (5 minutes)
     */
    const CACHE_DURATION = 300;
    
    /**
     * Cache key prefix
     */
    const CACHE_PREFIX = 'lectus_academy_restoration_';
    
    /**
     * Initialize the test restoration system
     */
    public static function init() {
        add_action('admin_init', array(__CLASS__, 'handle_restoration_request'));
    }
    
    /**
     * Handle restoration requests with improved security and validation
     */
    public static function handle_restoration_request() {
        // Check if this is a restoration request
        if (!isset($_POST['restore_test_configuration'])) {
            return;
        }
        
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['restoration_nonce'], 'restore_test_configuration')) {
            wp_die(__('Security check failed. Please try again.', 'lectus-academy'));
        }
        
        // Check user capabilities
        if (!current_user_can('edit_theme_options')) {
            wp_die(__('You do not have sufficient permissions to perform this action.', 'lectus-academy'));
        }
        
        // Proceed with restoration
        self::restore_complete_configuration();
    }
    
    /**
     * Main restoration function - restores complete test site configuration
     */
    public static function restore_complete_configuration() {
        $results = array();
        
        try {
            // Step 1: Create all essential pages
            if (isset($_POST['restore_pages'])) {
                $results['pages'] = self::create_essential_pages();
            }
            
            // Step 2: Create navigation menus
            if (isset($_POST['restore_menus'])) {
                $results['menus'] = self::create_navigation_menus();
            }
            
            // Step 3: Set theme options and configurations
            if (isset($_POST['restore_theme_options'])) {
                $results['theme_options'] = self::set_theme_options();
            }
            
            // Step 4: Configure WooCommerce pages if available
            if (isset($_POST['restore_woocommerce']) && self::is_woocommerce_active()) {
                $results['woocommerce'] = self::configure_woocommerce_pages();
            }
            
            // Step 5: Set up widgets and sidebars
            if (isset($_POST['restore_widgets'])) {
                $results['widgets'] = self::setup_default_widgets();
            }
            
            // Step 6: Import Lectus test data if plugin is active
            if (isset($_POST['restore_lectus_data']) && self::is_lectus_plugin_active()) {
                $results['lectus_data'] = self::trigger_lectus_test_data();
            }
            
            // Flush rewrite rules to ensure URLs work properly
            flush_rewrite_rules();
            
            // Display success message with sanitized output
            add_action('admin_notices', function() use ($results) {
                echo '<div class="notice notice-success"><p><strong>' . 
                     esc_html__('테스트 구성 복원 완료!', 'lectus-academy') . '</strong><br>';
                foreach ($results as $category => $data) {
                    $category_name = esc_html(ucfirst($category));
                    if (is_array($data)) {
                        echo sprintf(
                            '%s: %d개 항목 생성<br>',
                            $category_name,
                            intval(count($data))
                        );
                    } else {
                        echo sprintf(
                            '%s: %s<br>',
                            $category_name,
                            esc_html($data)
                        );
                    }
                }
                echo '</p></div>';
            });
            
        } catch (Exception $e) {
            // Log the error for debugging
            error_log('Lectus Academy Test Restoration Error: ' . $e->getMessage());
            
            add_action('admin_notices', function() use ($e) {
                echo '<div class="notice notice-error"><p><strong>' . 
                     esc_html__('복원 중 오류 발생:', 'lectus-academy') . '</strong> ' . 
                     esc_html($e->getMessage()) . '</p></div>';
            });
        }
    }
    
    /**
     * Create all essential pages for the test site
     * 
     * @return array List of created page titles
     * @throws Exception If page creation fails
     */
    public static function create_essential_pages() {
        $pages = array(
            array(
                'title' => '강의 목록',
                'slug' => 'courses',
                'content' => '[lectus_course_list]',
                'template' => 'page-courses.php'
            ),
            array(
                'title' => '내 강의',
                'slug' => 'my-courses',
                'content' => '[lectus_my_courses]',
                'template' => 'page-my-courses.php'
            ),
            array(
                'title' => '내 수료증',
                'slug' => 'my-certificates',
                'content' => '[lectus_certificates]',
                'template' => 'page-certificates.php'
            ),
            array(
                'title' => '수료증 확인',
                'slug' => 'certificate-verify',
                'content' => '[lectus_certificate_verify]',
                'template' => 'page-verify.php'
            ),
            array(
                'title' => '학습 대시보드',
                'slug' => 'student-dashboard',
                'content' => '[lectus_student_dashboard]',
                'template' => 'page-dashboard.php'
            ),
            array(
                'title' => 'Test Certificates',
                'slug' => 'test-certificates',
                'content' => '[lectus_certificates show_all="yes"]',
                'template' => 'page-test-certificates.php'
            ),
            array(
                'title' => 'Student Dashboard',
                'slug' => 'student-dashboard-2',
                'content' => '[lectus_student_dashboard show_all="yes"]',
                'template' => 'page-student-dashboard.php'
            )
        );
        
        $created_pages = array();
        
        foreach ($pages as $page_data) {
            // Validate required page data
            if (empty($page_data['title']) || empty($page_data['slug'])) {
                continue;
            }
            
            // Check if page already exists
            $existing_page = get_page_by_path(sanitize_title($page_data['slug']));
            
            if (!$existing_page) {
                $page_args = array(
                    'post_title' => sanitize_text_field($page_data['title']),
                    'post_name' => sanitize_title($page_data['slug']),
                    'post_content' => wp_kses_post($page_data['content']),
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_author' => get_current_user_id(),
                    'menu_order' => 0
                );
                
                $page_id = wp_insert_post($page_args);
                
                if (is_wp_error($page_id)) {
                    throw new Exception(sprintf(
                        'Failed to create page "%s": %s',
                        $page_data['title'],
                        $page_id->get_error_message()
                    ));
                }
                
                if ($page_id) {
                    // Set page template if specified
                    if (isset($page_data['template'])) {
                        update_post_meta($page_id, '_wp_page_template', sanitize_file_name($page_data['template']));
                    }
                    
                    $created_pages[] = $page_data['title'];
                }
            }
        }
        
        return $created_pages;
    }
    
    /**
     * Create navigation menus with proper error handling
     * 
     * @return array List of created menu names
     * @throws Exception If menu creation fails
     */
    public static function create_navigation_menus() {
        $menus_created = array();
        
        // Check if Primary Menu already exists
        $primary_menu_name = 'Primary Menu';
        $existing_primary_menu = wp_get_nav_menu_object($primary_menu_name);
        
        if ($existing_primary_menu) {
            // Menu already exists, use it
            $primary_menu = $existing_primary_menu->term_id;
            $menus_created[] = 'Primary Menu (already existed)';
        } else {
            // Create Primary Menu
            $primary_menu = wp_create_nav_menu($primary_menu_name);
            if (is_wp_error($primary_menu)) {
                // Try with a different name if there's a conflict
                $primary_menu_name = 'Lectus Primary Menu';
                $primary_menu = wp_create_nav_menu($primary_menu_name);
                
                if (is_wp_error($primary_menu)) {
                    error_log('Failed to create Primary Menu: ' . $primary_menu->get_error_message());
                    $primary_menu = false;
                } else {
                    $menus_created[] = $primary_menu_name;
                }
            } else {
                $menus_created[] = 'Primary Menu';
            }
        }
        
        if ($primary_menu) {
            
            // Add menu items
            $menu_items = array(
                array('title' => '홈', 'url' => home_url()),
                array('title' => '강의 목록', 'page_slug' => 'courses'),
                array('title' => '내 강의', 'page_slug' => 'my-courses'),
                array('title' => '수료증', 'page_slug' => 'my-certificates'),
                array('title' => '학습 대시보드', 'page_slug' => 'student-dashboard')
            );
            
            foreach ($menu_items as $item) {
                // Validate menu item data
                if (empty($item['title'])) {
                    continue;
                }
                
                if (isset($item['page_slug'])) {
                    $page = get_page_by_path(sanitize_title($item['page_slug']));
                    if ($page) {
                        $menu_item_result = wp_update_nav_menu_item($primary_menu, 0, array(
                            'menu-item-title' => sanitize_text_field($item['title']),
                            'menu-item-object' => 'page',
                            'menu-item-object-id' => intval($page->ID),
                            'menu-item-type' => 'post_type',
                            'menu-item-status' => 'publish'
                        ));
                        
                        if (is_wp_error($menu_item_result)) {
                            error_log('Failed to add menu item: ' . $menu_item_result->get_error_message());
                        }
                    }
                } elseif (isset($item['url'])) {
                    $menu_item_result = wp_update_nav_menu_item($primary_menu, 0, array(
                        'menu-item-title' => sanitize_text_field($item['title']),
                        'menu-item-url' => esc_url_raw($item['url']),
                        'menu-item-type' => 'custom',
                        'menu-item-status' => 'publish'
                    ));
                    
                    if (is_wp_error($menu_item_result)) {
                        error_log('Failed to add menu item: ' . $menu_item_result->get_error_message());
                    }
                }
            }
            
            // Assign menu to location
            $locations = get_theme_mod('nav_menu_locations', array());
            $locations['primary'] = $primary_menu;
            set_theme_mod('nav_menu_locations', $locations);
        }
        
        // Check if Footer Menu already exists
        $footer_menu_name = 'Footer Menu';
        $existing_footer_menu = wp_get_nav_menu_object($footer_menu_name);
        
        if ($existing_footer_menu) {
            // Menu already exists, use it
            $footer_menu = $existing_footer_menu->term_id;
            $menus_created[] = 'Footer Menu (already existed)';
        } else {
            // Create Footer Menu
            $footer_menu = wp_create_nav_menu($footer_menu_name);
            if (is_wp_error($footer_menu)) {
                // Try with a different name if there's a conflict
                $footer_menu_name = 'Lectus Footer Menu';
                $footer_menu = wp_create_nav_menu($footer_menu_name);
                
                if (is_wp_error($footer_menu)) {
                    error_log('Failed to create Footer Menu: ' . $footer_menu->get_error_message());
                    $footer_menu = false;
                } else {
                    $menus_created[] = $footer_menu_name;
                }
            } else {
                $menus_created[] = 'Footer Menu';
            }
        }
        
        if ($footer_menu) {
            
            $footer_items = array(
                array('title' => '개인정보 처리방침', 'page_slug' => 'privacy-policy'),
                array('title' => '수료증 확인', 'page_slug' => 'certificate-verify'),
                array('title' => '고객 지원', 'url' => home_url('/contact'))
            );
            
            foreach ($footer_items as $item) {
                // Validate footer menu item data
                if (empty($item['title'])) {
                    continue;
                }
                
                if (isset($item['page_slug'])) {
                    $page = get_page_by_path(sanitize_title($item['page_slug']));
                    if ($page) {
                        $menu_item_result = wp_update_nav_menu_item($footer_menu, 0, array(
                            'menu-item-title' => sanitize_text_field($item['title']),
                            'menu-item-object' => 'page',
                            'menu-item-object-id' => intval($page->ID),
                            'menu-item-type' => 'post_type',
                            'menu-item-status' => 'publish'
                        ));
                        
                        if (is_wp_error($menu_item_result)) {
                            error_log('Failed to add footer menu item: ' . $menu_item_result->get_error_message());
                        }
                    }
                } elseif (isset($item['url'])) {
                    $menu_item_result = wp_update_nav_menu_item($footer_menu, 0, array(
                        'menu-item-title' => sanitize_text_field($item['title']),
                        'menu-item-url' => esc_url_raw($item['url']),
                        'menu-item-type' => 'custom',
                        'menu-item-status' => 'publish'
                    ));
                    
                    if (is_wp_error($menu_item_result)) {
                        error_log('Failed to add footer menu item: ' . $menu_item_result->get_error_message());
                    }
                }
            }
            
            // Assign footer menu to location
            $locations = get_theme_mod('nav_menu_locations', array());
            $locations['footer'] = $footer_menu;
            set_theme_mod('nav_menu_locations', $locations);
        }
        
        return $menus_created;
    }
    
    /**
     * Set theme options and configurations
     */
    public static function set_theme_options() {
        $options_set = array();
        
        // Set custom logo
        $options_set[] = 'Custom logo placeholder';
        
        // Set theme customizer options with validation
        $theme_options = array(
            'lectus_academy_accent_color' => sanitize_hex_color('#2090c0'),
            'lectus_academy_header_style' => sanitize_key('default'),
            'lectus_academy_footer_text' => sanitize_text_field('© 2024 Lectus Academy. All rights reserved.')
        );
        
        foreach ($theme_options as $option_key => $option_value) {
            if ($option_value) {
                set_theme_mod($option_key, $option_value);
            }
        }
        
        $options_set[] = 'Theme colors and styling';
        
        // Set homepage display
        update_option('show_on_front', 'page');
        
        // Create a front page if it doesn't exist
        $front_page = get_page_by_path('home');
        if (!$front_page) {
            $front_page_id = wp_insert_post(array(
                'post_title' => 'Home',
                'post_name' => 'home',
                'post_content' => '<h1>Lectus Academy에 오신 것을 환영합니다</h1>
                <p>최고의 온라인 교육 플랫폼에서 여러분의 학습 여정을 시작하세요.</p>
                [lectus_featured_courses limit="6"]
                [lectus_course_categories]',
                'post_status' => 'publish',
                'post_type' => 'page'
            ));
            
            if ($front_page_id && !is_wp_error($front_page_id)) {
                update_option('page_on_front', $front_page_id);
                $options_set[] = 'Homepage creation and setup';
            }
        }
        
        // Set permalink structure
        update_option('permalink_structure', '/%postname%/');
        
        $options_set[] = 'Permalink structure';
        
        return $options_set;
    }
    
    /**
     * Configure WooCommerce pages if WooCommerce is active
     */
    public static function configure_woocommerce_pages() {
        if (!self::is_woocommerce_active()) {
            return array('WooCommerce not active');
        }
        
        $configured = array();
        
        // Set WooCommerce page options
        $wc_pages = array(
            'shop' => get_page_by_path('shop'),
            'cart' => get_page_by_path('cart'),
            'checkout' => get_page_by_path('checkout'),
            'myaccount' => get_page_by_path('my-account')
        );
        
        foreach ($wc_pages as $option => $page) {
            // Validate option name and page
            $option = sanitize_key($option);
            if ($page && is_object($page) && property_exists($page, 'ID')) {
                $page_id = intval($page->ID);
                if ($page_id > 0) {
                    update_option('woocommerce_' . $option . '_page_id', $page_id);
                    $configured[] = ucfirst($option) . ' page';
                }
            }
        }
        
        // Configure WooCommerce settings for digital products
        update_option('woocommerce_downloads_require_login', 'yes');
        update_option('woocommerce_enable_guest_checkout', 'no');
        update_option('woocommerce_registration_generate_username', 'yes');
        update_option('woocommerce_registration_generate_password', 'yes');
        
        $configured[] = 'WooCommerce digital product settings';
        
        return $configured;
    }
    
    /**
     * Setup default widgets
     */
    public static function setup_default_widgets() {
        $widgets_setup = array();
        
        // Setup course sidebar widgets
        $course_sidebar_widgets = array(
            'search' => array(
                'title' => '강의 검색'
            ),
            'text' => array(
                'title' => '학습 안내',
                'text' => '<p>온라인 강의 수강에 도움이 필요하시면 언제든지 문의해 주세요.</p>
                           <p><strong>고객지원:</strong> support@lectusacademy.com</p>'
            )
        );
        
        // Note: Widget setup requires more complex implementation
        // This is a placeholder for widget configuration
        $widgets_setup[] = 'Course sidebar configuration';
        
        return $widgets_setup;
    }
    
    /**
     * Trigger Lectus Class System test data generation with security checks
     * 
     * @return string Status message
     */
    public static function trigger_lectus_test_data() {
        if (!self::is_lectus_plugin_active()) {
            return 'Lectus plugin not active';
        }
        
        // Additional security check
        if (!current_user_can('manage_options')) {
            return 'Insufficient permissions';
        }
        
        // Check if the test data function exists
        if (function_exists('lectus_generate_test_data')) {
            // Store original POST data
            $original_post = $_POST;
            
            // Set up secure POST data for the plugin
            $secure_post_data = array(
                'create_categories' => '1',
                'create_packages' => '1', 
                'create_courses' => '1',
                'create_lessons' => '1',
                'create_students' => '1',
                'create_enrollments' => '1',
                'create_products' => '1',
                'create_certificates' => '1'
            );
            
            // Temporarily set POST data
            $_POST = array_merge($_POST, $secure_post_data);
            
            try {
                // Call the plugin's test data generation function
                lectus_generate_test_data();
                $result = 'Lectus test data generated successfully';
            } catch (Exception $e) {
                error_log('Lectus test data generation failed: ' . $e->getMessage());
                $result = 'Test data generation failed';
            } finally {
                // Restore original POST data
                $_POST = $original_post;
            }
            
            return $result;
        }
        
        return 'Lectus test data function not available';
    }
    
    /**
     * Check if WooCommerce is active with caching
     * 
     * @return bool True if WooCommerce is active
     */
    public static function is_woocommerce_active() {
        static $is_active = null;
        
        if (null === $is_active) {
            $is_active = class_exists('WooCommerce');
        }
        
        return $is_active;
    }
    
    /**
     * Check if Lectus Class System plugin is active with caching
     * 
     * @return bool True if Lectus plugin is active
     */
    public static function is_lectus_plugin_active() {
        static $is_active = null;
        
        if (null === $is_active) {
            $is_active = function_exists('lectus_class_system_init') && 
                        defined('LECTUS_PLUGIN_VERSION');
        }
        
        return $is_active;
    }
    
    /**
     * Get current configuration status with caching
     * 
     * @return array Configuration status information
     */
    public static function get_configuration_status() {
        $cache_key = self::CACHE_PREFIX . 'status';
        $cached_status = wp_cache_get($cache_key);
        
        if (false !== $cached_status) {
            return $cached_status;
        }
        
        $status = array();
        
        // Check pages
        $essential_pages = array('courses', 'my-courses', 'my-certificates', 'student-dashboard', 'certificate-verify');
        $existing_pages = 0;
        
        foreach ($essential_pages as $slug) {
            if (get_page_by_path($slug)) {
                $existing_pages++;
            }
        }
        
        $status['pages'] = sprintf(
            '%d/%d pages exist',
            $existing_pages,
            count($essential_pages)
        );
        
        // Check menus
        $menus = get_terms(array(
            'taxonomy' => 'nav_menu',
            'hide_empty' => false,
            'fields' => 'count'
        ));
        $status['menus'] = intval($menus) . ' navigation menus configured';
        
        // Check theme options
        $front_page = get_option('page_on_front');
        $status['theme_options'] = $front_page ? 'Homepage configured' : 'No homepage set';
        
        // Check WooCommerce
        $status['woocommerce'] = self::is_woocommerce_active() ? 'WooCommerce active' : 'WooCommerce not active';
        
        // Check Lectus plugin
        $status['lectus_plugin'] = self::is_lectus_plugin_active() ? 'Lectus plugin active' : 'Lectus plugin not active';
        
        // Cache the result
        wp_cache_set($cache_key, $status, '', self::CACHE_DURATION);
        
        return $status;
    }
    
    /**
     * Admin page content for test restoration
     */
    public static function admin_page_content() {
        $status = self::get_configuration_status();
        ?>
        <div class="wrap">
            <h2><?php _e('테스트 사이트 구성 복원', 'lectus-academy'); ?></h2>
            
            <div class="notice notice-info">
                <p><?php _e('⚠️ 주의: 이 기능은 개발 및 테스트 목적으로만 사용하세요. 실제 운영 사이트에서는 신중하게 사용하세요.', 'lectus-academy'); ?></p>
            </div>
            
            <h3><?php _e('현재 구성 상태', 'lectus-academy'); ?></h3>
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('구성 요소', 'lectus-academy'); ?></th>
                        <th><?php _e('상태', 'lectus-academy'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($status as $component => $status_text): ?>
                    <tr>
                        <td><?php echo esc_html(ucfirst(str_replace('_', ' ', $component))); ?></td>
                        <td><?php echo esc_html($status_text); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <form method="post" action="">
                <?php wp_nonce_field('restore_test_configuration', 'restoration_nonce'); ?>
                
                <h3><?php _e('복원할 구성 요소 선택', 'lectus-academy'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('페이지 생성', 'lectus-academy'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="restore_pages" value="1" checked />
                                <?php _e('필수 페이지 생성 (강의 목록, 내 강의, 수료증 등)', 'lectus-academy'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('메뉴 구성', 'lectus-academy'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="restore_menus" value="1" checked />
                                <?php _e('기본 네비게이션 메뉴 생성', 'lectus-academy'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('테마 설정', 'lectus-academy'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="restore_theme_options" value="1" checked />
                                <?php _e('테마 옵션 및 홈페이지 설정', 'lectus-academy'); ?>
                            </label>
                        </td>
                    </tr>
                    <?php if (self::is_woocommerce_active()): ?>
                    <tr>
                        <th scope="row"><?php _e('WooCommerce 설정', 'lectus-academy'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="restore_woocommerce" value="1" checked />
                                <?php _e('WooCommerce 페이지 연결 및 설정', 'lectus-academy'); ?>
                            </label>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th scope="row"><?php _e('위젯 설정', 'lectus-academy'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="restore_widgets" value="1" />
                                <?php _e('기본 위젯 및 사이드바 구성', 'lectus-academy'); ?>
                            </label>
                        </td>
                    </tr>
                    <?php if (self::is_lectus_plugin_active()): ?>
                    <tr>
                        <th scope="row"><?php _e('Lectus 테스트 데이터', 'lectus-academy'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="restore_lectus_data" value="1" checked />
                                <?php _e('Lectus 플러그인 테스트 데이터 생성', 'lectus-academy'); ?>
                            </label>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
                
                <p class="submit">
                    <input type="submit" name="restore_test_configuration" class="button button-primary" 
                           value="<?php _e('테스트 구성 복원 실행', 'lectus-academy'); ?>"
                           onclick="return confirm('정말로 테스트 구성을 복원하시겠습니까? 일부 기존 설정이 변경될 수 있습니다.');" />
                </p>
            </form>
            
            <hr>
            
            <h3><?php _e('생성될 페이지 목록', 'lectus-academy'); ?></h3>
            <ul>
                <li><strong>강의 목록</strong> (/courses) - 모든 강의를 표시하는 페이지</li>
                <li><strong>내 강의</strong> (/my-courses) - 수강 중인 강의 목록</li>
                <li><strong>내 수료증</strong> (/my-certificates) - 수료증 관리 페이지</li>
                <li><strong>수료증 확인</strong> (/certificate-verify) - 수료증 검증 페이지</li>
                <li><strong>학습 대시보드</strong> (/student-dashboard) - 학습 현황 대시보드</li>
                <li><strong>Test Certificates</strong> (/test-certificates) - 테스트용 수료증 페이지</li>
                <li><strong>Student Dashboard</strong> (/student-dashboard-2) - 테스트용 대시보드</li>
            </ul>
            
            <h3><?php _e('추가 구성 내용', 'lectus-academy'); ?></h3>
            <ul>
                <li>Primary Menu 및 Footer Menu 생성</li>
                <li>홈페이지 설정 및 테마 옵션 구성</li>
                <li>WooCommerce 페이지 연결 (WooCommerce 활성화 시)</li>
                <li>Lectus Class System 테스트 데이터 생성 (플러그인 활성화 시)</li>
                <li>Permalink 구조 최적화</li>
            </ul>
        </div>
        <?php
    }
}

// Initialize the test restoration system
Lectus_Academy_Test_Restoration::init();