<?php
// Backup of original single-coursesingle.php - This is a copy for reference
?>